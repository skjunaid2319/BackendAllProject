package Singlelevel.inheritinc;

public class Main {

	public static void main(String[] args) {
		
		Child cd= new Child();
		System.out.println(cd.fatherName);
		System.out.println(cd.childName);

	}

}
