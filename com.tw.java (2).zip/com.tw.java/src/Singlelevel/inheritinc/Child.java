package Singlelevel.inheritinc;

public class Child extends Prant {
	String childName="Mohammad junaid IT Developer IN Sha ALLHA";

}
