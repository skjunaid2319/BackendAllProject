package Singlelevel.inheritinc;

public class Prant {
	String fatherName="Mohammad Zaher Sahab";

}
