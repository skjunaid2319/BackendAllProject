package Multipul.Inheritanc;

public class  Father extends GrandFather {

	String car="My new car Audi ";
	String house="Banglo";

}
