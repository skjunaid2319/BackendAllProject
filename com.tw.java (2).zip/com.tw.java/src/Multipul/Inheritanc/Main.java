package Multipul.Inheritanc;

public class Main {

	public static void main(String[] args) {
		Child ch = new Child();
		System.out.println(ch.name);
		System.out.println(ch.car);
		System.out.println(ch.house);
		System.out.println(ch.wirasat);
		
		

	}

}
