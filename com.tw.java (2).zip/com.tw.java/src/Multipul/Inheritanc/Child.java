package Multipul.Inheritanc;

public class Child extends Father {
	
	String name="Mohammad junaid";

}
