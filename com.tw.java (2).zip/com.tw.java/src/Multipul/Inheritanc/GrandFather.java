package Multipul.Inheritanc;

public class GrandFather {
	
	String wirasat="Mare werasat mare bate kay liya ";

}
