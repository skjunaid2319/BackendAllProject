package polymorfisim;

public class ElectricCar extends Car {
	
              //  What is Polymorphism
	
	// is a process of  perform one task in different
	// ways  (like) man & son & is a father & is a husbnd
	// is a employee & ect that is Polymorphism
	
		void charging() {
			System.out.println("Thes car is one by cherging");
		}

}
