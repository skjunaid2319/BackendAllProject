
public class ForLoop {

	public static void main(String[] args) {
		
		
//		for(int i = 1 ; i <=20;i++) {
//			System.out.println(i);
//			
//		}
		
		String [] name = {"junaid ","zeeshan","juniad bhai"};
		System.out.println(name[2]);
		
//		int x = 10;
//		int y = 20;
//		int z = 30;
//		if(x > y) {
//			System.out.println("x is a greater than");
//		}


	}
	

}



