
public class PrictesForLoop {

	public static void main(String[] args) {
		
//		for (int i = 1 ; i <=10;i++) {
//			System.out.println(i);
//		}
		
		String [] name  = {"Uzaif","Arfat","Ismaill"};
		System.out.println(name[2]);
	}

}
