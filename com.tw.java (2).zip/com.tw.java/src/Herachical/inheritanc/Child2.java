package Herachical.inheritanc;

public class Child2 extends Father {
	String neew="My somthing house is ";

}
