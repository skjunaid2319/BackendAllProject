package Herachical.inheritanc;

public class Father {
	String name ="Multpal Child in one prant";
	
	
                     

}
