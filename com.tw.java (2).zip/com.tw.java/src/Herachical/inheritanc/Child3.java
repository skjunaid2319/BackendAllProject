package Herachical.inheritanc;

public class Child3 extends Father {
	String names="one prants is three chaild";

}
