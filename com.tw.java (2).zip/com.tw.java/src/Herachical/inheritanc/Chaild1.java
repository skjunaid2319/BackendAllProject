package Herachical.inheritanc;

public class Chaild1 extends Father {
	String names="My fucher car is samthing";

}


