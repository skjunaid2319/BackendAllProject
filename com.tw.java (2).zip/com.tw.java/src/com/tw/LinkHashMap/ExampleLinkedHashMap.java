package com.tw.LinkHashMap;

import java.util.LinkedHashMap;

public class ExampleLinkedHashMap {

	public static void main(String[] args) {
	
		 LinkedHashMap<String, Integer> li = new LinkedHashMap<>();
		 
		 li.put("Mdjunaid",29 );
		 li.put("Zeeshan",28 );
		 li.put("Taha", 23);
		 li.put("Noman",23 );
		 li.put("Imtiyaz", 23);
		 li.put("junaid", 24);
		 
		 System.out.println(li);
		 
		 li.remove("Imtiyaz", 23);
		 System.out.println(li);
		 
		 System.out.println(li.size());
		 
//		 li.keySet();
		 System.out.println(li.keySet());
		 
		 
//		 li.clear();
//		 System.out.println(li);
	
		 li.entrySet();
		 System.out.println(li);
		 
		 
		 
		 System.out.println(li.containsKey("Mdjunaid"));
		 System.out.println(li.containsKey("Raza Zeeshan"));
		 
		 
		 


	}

}
