package com.tw.abstaction;

public abstract class Branch {
	
	public abstract void car(double fucher,int fucherincar);
	public abstract void newcar(double fucher,int fucherincar);
	public abstract void newfucherincar(double fucher,int fucherincar);
	
	public void printNew() {
		System.out.println("car");
	}
	

}
