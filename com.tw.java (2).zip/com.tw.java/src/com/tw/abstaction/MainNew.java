package com.tw.abstaction;

public class MainNew {

	public static void main(String[] args) {
		Branch objbra=new NewBranch();
		
		objbra.car(1000000, 231);
		objbra.newcar(1500000, 765);
		objbra.newfucherincar(2000000, 0543);
	}

}
