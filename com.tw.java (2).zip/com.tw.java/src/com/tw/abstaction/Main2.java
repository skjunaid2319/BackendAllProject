package com.tw.abstaction;

public class Main2 extends CarCom {

	@Override
	public void BMW(double amount, int accountNumber) {
		

	}

	@Override
	public void AUDI(double amount, int accountNumber) {
		

	}

	@Override
	public void INDOVAR(double amount, int accountNumber) {
		

	}

}
