package com.tw.abstaction;

public class MainClass {

	public static void main(String[] args) {
		RBI objsbi=new SBI();
		
		objsbi.deposit(100, 981);
		objsbi.withdraw(200, 981);
		objsbi.cheakBlance(1200, 981);
		
		
	}

}
