package PrictesInJava;

public class JavaPrictes {

	public static void main(String[] args) {
		
		 // (Array in java)
		
//		String [] name = {"Moshin","Fairden","Mudassir","Fayyaz"};
//		System.out.println(name[3]);
//		
		// (Java For Loop)
		
//		for(int i = 1; i <=20;i++) {
//			System.out.println(i);
//		}
		
		// (Java Declare Multiple Variables)
		
//		int x = 5, y = 10, z = 35;
//		System.out.println(x + y + z);
		
		// (Java Characters)
		
//		char myGrade = 'B';
//		System.out.println(myGrade);
		
//		String fastName = "Md";
//		String lastName = "Junaid";
//	    System.out.println(fastName + " " + lastName 	);
		
		// Java Numbers and Strings
		
//	    int a = 10;     
//	    String b = "20";
//	    int c = 30;                   
//	    System.out.println(a + b + c);
		
		// (Java if)
		
//		int x = 20;
//		int y = 10;
//		if(x > y) {
//			System.out.println("x is a great than");
//		}
		
		// (If Else in java) 
		
//		int time = 5;
//		if(time < 3) {
//			System.out.println("Good Morning.");
//		}else {
//			System.out.println("Good Night.");
//		}
		
		// (Java Switch Statements)
		
//		int day = 4;
//		switch (day) {
//		   case 1:
//			   System.out.println("Monday");
//			   break;
//		   case 2:
//			   System.out.println("Tuesday");
//			   break;
//		   case 3:
//			   System.out.println("wednesday");
//			   break;
//		   case 4:
//			   System.out.println("Thursday");
//			   break;
//		   case 5:
//			   System.out.println("Friday");
//			   break;
//		   case 6:
//			   System.out.println("Saturday");
//			   break;
//		   case 7:
//			   System.out.println("Sunday");
//			   break;
//		}
////		
//         ( Java While Loop)
		
//		    int  i = 0 ;
//		    while (i < 5 ) {
//		    	System.out.println(i++);
//		    }
		
		// (Java For Each Loop)
		
//		String [] cars = {"BMW","FORD","INDOVER","AUDI"};
//		for (String i : cars) {
//			System.out.println(i);
//		}
		
		// (Java Break and Continue Loop)
		
//		for (int i = 0 ; i < 10;i++) {
//			if (i==4) {
//				break;
//			}
//			System.out.println(i);
//		}
//      
//       (Java Method Parameters)
		
//		public class Main {
//		  static void myMethod(String fname) {
//			    System.out.println(fname + " Refsnes");
//			  }
//
//			  public static void main1(String[] args) {
//			    myMethod("Liam");
//			    myMethod("Jenny");
//			    myMethod("Anja");
//			  }
//			}
		// Array of index  position is zero
		
	    String [] array = {"BMW", "Fod","Audi"};
	    System.out.println(array[1]);
		
	}

}
					