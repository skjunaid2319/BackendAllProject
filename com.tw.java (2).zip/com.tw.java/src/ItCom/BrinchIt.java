package ItCom;

public class BrinchIt implements ItComPany1 {

	@Override
	public String details() {
		return "Student details  ";
	}

	@Override
	public String fullStackDeveloper() {
			return " communi kashion skill ";
	}

	@Override
	public String frendEnd() {
		return "Guid line place ment";
	}

	@Override
	public String payMent() {
				return "Payment 50000";
	}

	@Override
	public String classTime() {
		
		return "interview preparation";
	}

	@Override
	public String reailTimeProject() {
		
		return "corse closed & hand over project";
	}

}
