package ItCom;

public interface ItComPany1 {
	
	
	String details();
	String fullStackDeveloper();
	String frendEnd();
	String payMent();
	String classTime();
	String reailTimeProject();
	

}
