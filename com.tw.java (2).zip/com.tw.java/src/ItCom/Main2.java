package ItCom;

public class Main2 {

	public static void main(String[] args) {
		ItComPany1 it=new BrinchIt();
	
		it.details();
		it.frendEnd();
		it.fullStackDeveloper();
		it.reailTimeProject();
	}

}
