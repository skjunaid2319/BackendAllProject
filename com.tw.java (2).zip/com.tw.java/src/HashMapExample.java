import java.util.HashMap;
import java.util.Map;

public class HashMapExample {

	private static Map<String, Integer> map;

	public static void main(String[] args) {
		
		Map<String,Integer> m = new HashMap<>();
		
		m.put("Junaid", 24);
		m.put("Zeeshan", 27);
		m.put("Amer",  26);
		m.put("Taha",  23);
		System.out.println(m);
		
		m.containsKey("Zeeshan");
		System.out.println(m.containsKey("Zeeshan"));
		System.out.println(m.containsKey("Zeeshan Raza"));
		
		System.out.println("it will check is empty or not "+m.isEmpty());
		
		System.out.println(m.entrySet());
		System.out.println(m.remove("Amer"));
		System.out.println(m.size());
		
		m.values();
		System.out.println(m);
		
		m.clear();
		System.out.println(m);
		

	}

}
